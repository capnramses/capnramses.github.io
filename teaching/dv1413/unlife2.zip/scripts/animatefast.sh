convert -delay 3 -depth 8 -size 512x512 out_*.png animation.gif
