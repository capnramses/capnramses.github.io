g++ -c src/* -I include/
g++ -o unlife *.o
