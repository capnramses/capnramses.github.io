#!/bin/bash
SIZE="128x128"
for i in {0..9}; do
convert -depth 8 -size $SIZE gray:img_hour_00000$i.raw out_00000$i.png
done
for i in {10..99}; do
convert -depth 8 -size $SIZE gray:img_hour_0000$i.raw out_0000$i.png
done
for i in {100..999}; do
convert -depth 8 -size $SIZE gray:img_hour_000$i.raw out_000$i.png
done
for i in {1000..1999}; do
convert -depth 8 -size $SIZE gray:img_hour_00$i.raw out_00$i.png
done
