for i in {0..100} do;

done;

