for i in {0..10000}; do
./unlife 1000 100 > result$i.txt
done
