SIZE="128x128"
convert -delay 5 -depth 8 -size $SIZE out_*.png animation.gif
