#ifndef _SURVIVOR_H_
#define _SURVIVOR_H_

struct Survivor {
	void create();
	int getDefence();
	int experience;
	int chanceToDefend;
	int chanceToKill;
	bool isImmune;
};

#endif

