#ifndef _BEHAVIOUR_H_
#define _BEHAVIOUR_H_

bool eatSurvivor(int x, int y);
bool zombieAttack(int x, int y);
void zombieAttemptMoveFromTo(int xi, int yi, int xf, int yf);
bool zombieChase(const int& x, const int& y);
void zombieWander(int x, int y);
void civilianAttemptMoveFromTo(int xi, int yi, int xf, int yf);
bool civilianRunAway(int x, int y);
void civilianMove(int x, int y);
bool shootZombie(int x, int y);
bool soldierAttack(int x, int y);
void soldierAttemptMoveFromTo(int xi, int yi, int xf, int yf);
bool soldierFormation(int x, int y);
void soldierMove(int x, int y);
bool appendStats();

#endif

