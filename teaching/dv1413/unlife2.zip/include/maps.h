#ifndef _MAPSXX_H_
#define _MAPSXX_H_

#include "survivor.h"

#define MAPWIDTH 128
#define MAPHEIGHT 128

struct Maps {
	Maps();
	Survivor* survivorMap[MAPWIDTH][MAPHEIGHT];
	bool zombieMap[MAPWIDTH][MAPHEIGHT];
	bool zombieMovedMap[MAPWIDTH][MAPHEIGHT];
	bool survivorMovedMap[MAPWIDTH][MAPHEIGHT];
	bool soldierMovedMap[MAPWIDTH][MAPHEIGHT];
	Survivor* soldierMap[MAPWIDTH][MAPHEIGHT];
	bool obstacleMap[MAPWIDTH][MAPHEIGHT];

	int survivorCount;
	int immuneCount;
	int soldierCount;
	int immuneSoldierCount;
	int zombieCount;
	int zombiesKilled;

	int survivorChance;
	//int zombieChance = 1;
	int soldierChance;
	int buildingCoveragePercent;
	int buildingSizeMin;
	int buildingSizeMax;

	void createObstacleMap();
	void createSurvivorMap();
	void resetMoveMaps();
	void printSurvivorPositions();
	void printZombiePositions();
	void printSoldierPositions();
};

extern Maps gMaps;

#endif

