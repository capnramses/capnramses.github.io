#include <stdio.h>
#include <string.h>
#include <fstream>
#include <vector>
#include <math.h>
using namespace std;

struct XValue {
	vector<float> yvalues;
	int x;
	float sumOfYValues;
	float meanOfYValues;
	float sumOfSqDifferencesFromMean;
	float standardDev;

	XValue() {
		sumOfYValues = meanOfYValues = sumOfSqDifferencesFromMean = standardDev = 0.0f;
	}
	void calcSum() {
		sumOfYValues = 0.0f;
		for (int i = 0; i < yvalues.size(); i++) {
			sumOfYValues += yvalues[i];
		}
	}
	void calcMean(int n) {
		meanOfYValues = sumOfYValues / (float)n;
	}
	void calcSumOfSqDiffs() {
		for (int i = 0; i < yvalues.size(); i++) {
			float sqdiff = (yvalues[i] - meanOfYValues) * (yvalues[i] - meanOfYValues);
			sumOfSqDifferencesFromMean += sqdiff;
		}
	}
	void calcStdDev(int n) {
			standardDev = sqrt(sumOfSqDifferencesFromMean / (n - 1));
	}
};

vector<XValue> xvalues;

int main(int argc, char** argv) {
	int count = 0;
	sscanf(argv[1], "%i", &count);
	printf("stats for %i results files with an x interval\n", count);
	// go through each file and add it's y value for each x to a total
	for (int i = 0; i < count; i++) {
		ifstream file;
		char filename[256];
		sprintf(filename, "result%i.txt", i);
		file.open(filename);
		if (!file.is_open()) {
			printf("error opening file %s\n", filename);
			return 1;
		}
		char buffer[1024];
		int index = 0;
		while (file.getline(buffer, 1024)) {
			int x = 0;
			int y = 0;
			sscanf(buffer, "%i %i", &x, &y);
			if (index >= xvalues.size()) {
				XValue xv;
				xv.x = x;
				xvalues.push_back(xv);
			}
			xvalues[index].yvalues.push_back(y);
			index++;
		}
		file.close();
	}
	ofstream fileout;
	fileout.open("plot.txt");
	if (!fileout.is_open()) {
		printf("error opening plot.txt\n");
		return 1;
	}
	
	for (int i = 0; i < xvalues.size(); i++) {
		// work out sum of y values for each x value
		xvalues[i].calcSum();
		// work out mean for each x value
		xvalues[i].calcMean(count);
		// sum of sq diffs from mean
		xvalues[i].calcSumOfSqDiffs();
		// std dev
		xvalues[i].calcStdDev(count);
		fileout << xvalues[i].x << "\t" << xvalues[i].meanOfYValues << "\t" << xvalues[i].standardDev << endl;
		
	}
	fileout.close();
	return 0;
}
