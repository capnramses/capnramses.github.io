#include "behaviour.h"
#include "maps.h"
#include <cstdio>
#include <cstdlib> // rand
using namespace std;

bool eatSurvivor(int x, int y) {
	// make sure map square is valid
	if (x < 0) { return false; }
	if (y < 0) { return false; }
	if (x > MAPWIDTH - 1) { return false; }
	if (y > MAPHEIGHT - 1) { return false; }
	
	// check map square for civilian
	if (NULL != gMaps.survivorMap[x][y]) {
		// let survivor try to defend
		int chance = rand() % 100;
			
		// check if eaten alive
		if (chance >= gMaps.survivorMap[x][y]->getDefence() + 20) {
			//printf("survivor has been eaten alive!\n");
			if (gMaps.survivorMap[x][y]->isImmune) {
				gMaps.immuneCount--;
			}
			delete gMaps.survivorMap[x][y];
			gMaps.survivorMap[x][y] = NULL;
			gMaps.survivorCount--;
			return true;
		}
		
		// check if nibbled and infected
		if (!gMaps.survivorMap[x][y]->isImmune) {
			if (chance >= gMaps.survivorMap[x][y]->getDefence()) {
				//printf("survivor has been infected!\n");
				delete gMaps.survivorMap[x][y];
				gMaps.survivorMap[x][y] = NULL;
				gMaps.survivorCount--;
				gMaps.zombieMap[x][y] = true;
				gMaps.zombieMovedMap[x][y] = true;
				gMaps.zombieCount++;
				return true;
			}
		}
		
		// survivor gets better at defending now
		gMaps.survivorMap[x][y]->experience++;
		return true;
		
	// check map square for soldier
	} else if (NULL != gMaps.soldierMap[x][y]) {
		// let soldier try to defend
		int chance = rand() % 100;
			
		// check if eaten alive
		if (chance >= gMaps.soldierMap[x][y]->getDefence() + 20) {
			//printf("soldier has been eaten alive!\n");
			if (gMaps.soldierMap[x][y]->isImmune) {
				gMaps.immuneSoldierCount--;
			}
			delete gMaps.soldierMap[x][y];
			gMaps.soldierMap[x][y] = NULL;
			gMaps.soldierCount--;
			return true;
		}
		
		// check if nibbled and infected
		if (!gMaps.soldierMap[x][y]->isImmune) {
			if (chance >= gMaps.soldierMap[x][y]->getDefence()) {
				//printf("soldier has been infected!\n");
				delete gMaps.soldierMap[x][y];
				gMaps.soldierMap[x][y] = NULL;
				gMaps.soldierCount--;
				gMaps.zombieMap[x][y] = true;
				gMaps.zombieMovedMap[x][y] = true;
				gMaps.zombieCount++;
				return true;
			}
		}
		
		// soldier gets better at defending now
		gMaps.soldierMap[x][y]->experience++;
		return true;
	}
	// no survivors on map square
	return false;
}

bool zombieAttack(int x, int y) {
	// up
	if (eatSurvivor(x, y - 1)) { return true; }
	// right
	if (eatSurvivor(x + 1, y)) { return true; }
	// down
	if (eatSurvivor(x, y + 1)) { return true; }
	// left
	if (eatSurvivor(x - 1, y)) { return true; }
	return false;
}

void zombieAttemptMoveFromTo(int xi, int yi, int xf, int yf) {
	// validate square
	if (xf < 0) { return; }
	if (yf < 0) { return; }
	if (xf > MAPWIDTH - 1) { return; }
	if (yf > MAPHEIGHT - 1) { return; }
	
	// check for zombie in the way - if so wait
	if (gMaps.zombieMap[xf][yf]) { return; }
	// check if building in way
	if (gMaps.obstacleMap[xf][yf]) { return; }
	
	// move
	gMaps.zombieMap[xf][yf] = true;
	// flag as "already moved this zombie"
	gMaps.zombieMovedMap[xf][yf] = true;
	// remove from original square
	gMaps.zombieMap[xi][yi] = false;
}

bool checkForCivilianIn(const int& x, const int& y) {
	// validate on map or not
	if (x < 0) { return false; }
	if (y < 0) { return false; }
	if (x > MAPWIDTH - 1) { return false; }
	if (y > MAPHEIGHT - 1) { return false; }
	
	// check map
	if (NULL == gMaps.survivorMap[x][y]) { return false; }
	return true;
}

bool zombieChase(const int& x, const int& y) {
	// top-right - move up
	if (checkForCivilianIn(x + 1, y - 1)) {
		zombieAttemptMoveFromTo(x, y, x, y - 1); 
		return true;
	}
	// bottom-right - move right
	if (checkForCivilianIn(x + 1, y + 1)) {
		zombieAttemptMoveFromTo(x, y, x + 1, y); 
		return true;
	}
	// bottom-left - move down
	if (checkForCivilianIn(x - 1, y + 1)) {
		zombieAttemptMoveFromTo(x, y, x, y + 1); 
		return true;
	}
	// top-left - move left
	if (checkForCivilianIn(x - 1, y - 1)) {
		zombieAttemptMoveFromTo(x, y, x - 1, y); 
		return true;
	}
	// a row 2 squares up - move up
	for (int tx = x - 1; tx <= x + 1; tx++) {
		if (checkForCivilianIn(tx, y - 2)) {
			zombieAttemptMoveFromTo(x, y, x, y - 1); 
			return true;
		}
	}
	// a row 2 squares right - move right
	for (int ty = y - 1; ty <= y + 1; ty++) {
		if (checkForCivilianIn(x + 2, ty)) {
			zombieAttemptMoveFromTo(x, y, x + 1, y); 
			return true;
		}
	}
	// a row 2 squares down - move down
	for (int tx = x - 1; tx <= x + 1; tx++) {
		if (checkForCivilianIn(tx, y + 2)) {
			zombieAttemptMoveFromTo(x, y, x, y + 1); 
			return true;
		}
	}
	// a row 2 squares left - move left
	for (int ty = y - 1; ty <= y + 1; ty++) {
		if (checkForCivilianIn(x - 2, ty)) {
			zombieAttemptMoveFromTo(x, y, x - 1, y); 
			return true;
		}
	}
	return false;
}

void zombieWander(int x, int y) {
	//printf("zombie wander\n");
	int dir = rand() % 4;
	if (0 == dir) {
		// try to move up
		zombieAttemptMoveFromTo(x, y, x, y - 1);
	} else if (1 == dir) {
		// try to move down
		zombieAttemptMoveFromTo(x, y, x, y + 1);
	} else if (2 == dir) {
		// try to move left
		zombieAttemptMoveFromTo(x, y, x - 1, y);
	} else {
		// try to move right
		zombieAttemptMoveFromTo(x, y, x + 1, y);
	}
}

void civilianAttemptMoveFromTo(int xi, int yi, int xf, int yf) {
	// validate move
	if (xf < 0) { return; }
	if (yf < 0) { return; }
	if (xf > MAPWIDTH - 1) { return; }
	if (yf > MAPHEIGHT - 1) { return; }
	
	// check if blocked by obstacles
	if (gMaps.obstacleMap[xf][yf]) { return; }
	// check if blocked by zombies or survivors or soldiers
	if (gMaps.zombieMap[xf][yf]) { return; }
	if (NULL != gMaps.survivorMap[xf][yf]) { return; }
	if (NULL != gMaps.soldierMap[xf][yf]) { return; }
	
	// move by switching pointer
	gMaps.survivorMap[xf][yf] = gMaps.survivorMap[xi][yi];
	gMaps.survivorMap[xi][yi] = NULL;
	gMaps.survivorMovedMap[xf][yf] = true;
}

bool checkForZombieIn(const int& x, const int& y) {
	// validate on map or not
	if (x < 0) { return false; }
	if (y < 0) { return false; }
	if (x > MAPWIDTH - 1) { return false; }
	if (y > MAPHEIGHT - 1) { return false; }
	// check map
	if (!gMaps.zombieMap[x][y]) { return false; }
	return true;
}

bool civilianRunAway(int x, int y) {
	// above
	if (checkForZombieIn(x, y - 1)) {
		civilianAttemptMoveFromTo(x, y, x, y + 1); 
		return true;
	}
	// right
	if (checkForZombieIn(x + 1, y)) {
		civilianAttemptMoveFromTo(x, y, x - 1, y); 
		return true;
	}
	// below
	if (checkForZombieIn(x, y + 1)) {
		civilianAttemptMoveFromTo(x, y, x, y - 1); 
		return true;
	}
	// left
	if (checkForZombieIn(x - 1, y)) {
		civilianAttemptMoveFromTo(x, y, x + 1, y); 
		return true;
	}
	// top-right
	if (checkForZombieIn(x + 1, y - 1)) {
		civilianAttemptMoveFromTo(x, y, x, y + 1); 
		return true;
	}
	// bottom-right
	if (checkForZombieIn(x + 1, y + 1)) {
		civilianAttemptMoveFromTo(x, y, x - 1, y); 
		return true;
	}
	// bottom-left
	if (checkForZombieIn(x - 1, y + 1)) {
		civilianAttemptMoveFromTo(x, y, x, y - 1); 
		return true;
	}
	// top-left
	if (checkForZombieIn(x - 1, y - 1)) {
		civilianAttemptMoveFromTo(x, y, x + 1, y); 
		return true;
	}
	
	// a row 2 squares up
	for (int tx = x - 1; tx <= x + 1; tx++) {
		if (checkForZombieIn(tx, y - 2)) {
			civilianAttemptMoveFromTo(x, y, x, y + 1); 
			return true;
		}
	}
	// a row 2 squares right
	for (int ty = y - 1; ty <= y + 1; ty++) {
		if (checkForZombieIn(x + 2, ty)) {
			civilianAttemptMoveFromTo(x, y, x - 1, y); 
			return true;
		}
	}
	// a row 2 squares down
	for (int tx = x - 1; tx <= x + 1; tx++) {
		if (checkForZombieIn(tx, y + 2)) {
			civilianAttemptMoveFromTo(x, y, x, y - 1); 
			return true;
		}
	}
	// a row 2 squares left
	for (int ty = y - 1; ty <= y + 1; ty++) {
		if (checkForZombieIn(x - 2, ty)) {
			civilianAttemptMoveFromTo(x, y, x + 1, y); 
			return true;
		}
	}
	
	return false;
}

void civilianMove(int x, int y) {
	//printf("civilian wander\n");
	int dir = rand() % 4;
	if (0 == dir) {
		// try to move up
		civilianAttemptMoveFromTo(x, y, x, y - 1);
	} else if (1 == dir) {
		// try to move down
		civilianAttemptMoveFromTo(x, y, x, y + 1);
	} else if (2 == dir) {
		// try to move left
		civilianAttemptMoveFromTo(x, y, x - 1, y);
	} else {
		// try to move right
		civilianAttemptMoveFromTo(x, y, x + 1, y);
	}
}

bool shootZombie(int x, int y) {
	// validate on map and has zombie
	if (!checkForZombieIn(x, y)) { return false; }
	// roll dice to shoot
	int chance = rand() % 100;
	if (chance < 80) {
		gMaps.zombieMap[x][y] = false;
		gMaps.zombieCount--;
		gMaps.zombiesKilled++;
		//printf("zombie shot\n");
	}
	return true;
}

bool soldierAttack(int x, int y) {
	if (shootZombie(x - 1, y)) { return true; }
	if (shootZombie(x + 1, y)) { return true; }
	if (shootZombie(x, y - 1)) { return true; }
	if (shootZombie(x, y + 1)) { return true; }
	return false;
}

void soldierAttemptMoveFromTo(int xi, int yi, int xf, int yf) {
	// validate on map or not
	if (xf < 0) { return; }
	if (yf < 0) { return; }
	if (xf > MAPWIDTH - 1) { return; }
	if (yf > MAPHEIGHT - 1) { return; }
	// check if building in way
	if (gMaps.obstacleMap[xf][yf]) { return; }
	// check if blocked by survivors or soldiers
	if (NULL != gMaps.survivorMap[xf][yf]) { return; }
	if (NULL != gMaps.soldierMap[xf][yf]) { return; }
	// move by switching pointer
	gMaps.soldierMap[xf][yf] = gMaps.soldierMap[xi][yi];
	gMaps.soldierMap[xi][yi] = NULL;
	gMaps.soldierMovedMap[xf][yf] = true;
}

bool soldierFormation(int x, int y) {
	// up
	for (int xf = x - 1; xf <= x + 1; xf++) {
		if (NULL != gMaps.soldierMap[xf][y - 2]) {
			soldierAttemptMoveFromTo(x, y, x, y - 1);
			return true;
		}
	}
	// right
	for (int yf = y - 1; yf <= y + 1; yf++) {
		if (NULL != gMaps.soldierMap[x + 2][yf]) {
			soldierAttemptMoveFromTo(x, y, x + 1, y);
			return true;
		}
	}
	// down
	for (int xf = x - 1; xf <= x + 1; xf++) {
		if (NULL != gMaps.soldierMap[xf][y + 2]) {
			soldierAttemptMoveFromTo(x, y, x, y + 1);
			return true;
		}
	}
	// left
	for (int yf = y - 1; yf <= y + 1; yf++) {
		if (NULL != gMaps.soldierMap[x - 2][yf]) {
			soldierAttemptMoveFromTo(x, y, x - 1, y);
			return true;
		}
	}
	return false;
}

void soldierMove(int x, int y) {
	int dir = rand() % 4;
	if (0 == dir) {
		// try to move up
		soldierAttemptMoveFromTo(x, y, x, y - 1);
	} else if (1 == dir) {
		// try to move down
		soldierAttemptMoveFromTo(x, y, x, y + 1);
	} else if (2 == dir) {
		// try to move left
		soldierAttemptMoveFromTo(x, y, x - 1, y);
	} else {
		// try to move right
		soldierAttemptMoveFromTo(x, y, x + 1, y);
	}
}

