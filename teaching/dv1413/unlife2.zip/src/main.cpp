#include "maps.h"
#include "behaviour.h"
#include <ctime>
#include <cstdlib>
#include <cstdio>
#include <cmath> // sqrt
#include <cstring>
#include <fstream>
using namespace std;

Maps gMaps;
int totalHours = 1000;
// only print every printervalth result
int printerval = 1;

bool writeRAW(int day);

int main(int argc, char** argv) {
	if (argc > 1) {
		sscanf(argv[1], "%i", &totalHours);
	}
	if (argc > 2) {
		sscanf(argv[2], "%i", &printerval);
	}
	// seed random number generator
	int seed = time(NULL);
	srand(seed);
	//printf("starting Artificial Unlife simulation\n of %i steps printing at every %i step\n with seed %i\n", totalHours, printerval, seed);
	gMaps.createObstacleMap();
	gMaps.createSurvivorMap();
	//printSurvivorPositions();
	//printZombiePositions();
	//printSoldierPositions();
	
	// open files for writing stats
	
	
	// start simulation
	//printf("start of hour 0: survivors=%i (%i immune) zombies=%i soldiers=%i (%i immune)\n", gMaps.survivorCount, gMaps.immuneCount, gMaps.zombieCount, gMaps.soldierCount, gMaps.immuneSoldierCount);
	for (int i = 0; i < totalHours; i++) {
		//printf("start of hour %i: survivors=%i (%i immune) zombies=%i soldiers=%i (%i immune)\n", i, gMaps.survivorCount, gMaps.immuneCount, gMaps.zombieCount, gMaps.soldierCount, gMaps.immuneSoldierCount);
		// reset zombie states
		gMaps.resetMoveMaps();
		// update zombies
		for (int y = 0; y < MAPHEIGHT; y++) {
			for (int x = 0; x < MAPWIDTH; x++) {
				// skip if no zombie in this square
				if (!gMaps.zombieMap[x][y]) { continue; }
				// skip if this zombie just moved here, or if it was just zombified
				if (gMaps.zombieMovedMap[x][y]) { continue; }
				// try to attack any adjacent civilian or soldier
				if (zombieAttack(x, y)) { continue; }
				// try to move towards any nearby civilians or soldiers
				if (zombieChase(x, y)) { continue; }
				// either wait around or move randomly
				int chance = rand() % 2;
				if (chance > 0) {
					zombieWander(x, y);
				}
			}
		}
		// update civilians
		for (int y = 0; y < MAPHEIGHT; y++) {
			for (int x = 0; x < MAPWIDTH; x++) {
				// skip if no civilian in this square
				if (NULL == gMaps.survivorMap[x][y]) { continue; }
				// skip if this civilian just moved here
				if (gMaps.survivorMovedMap[x][y]) { continue; }
				// try to run from nearby zombies
				if (civilianRunAway(x, y)) { continue; }
				// either wait around or move randomly
				int chance = rand() % 2;
				if (chance > 0) {
					civilianMove(x, y);
				}
			}
		}
		// update soldiers
		for (int y = 0; y < MAPHEIGHT; y++) {
			for (int x = 0; x < MAPWIDTH; x++) {
				// skip if no soldier in this square
				if (NULL == gMaps.soldierMap[x][y]) { continue; }
				// skip if this soldier just moved here
				if (gMaps.soldierMovedMap[x][y]) { continue; }
				// try to shoot zombies twice
				bool fired = false;
				if (soldierAttack(x, y)) { fired = true; }
				if (soldierAttack(x, y)) { fired = true; }
				// reload
				if (fired) { continue; }
				// attempt to join formation
				if (soldierFormation(x, y)) { continue; }
				// seek and destroy
				int chance = rand() % 2;
				if (chance > 0) {
					soldierMove(x, y);
				}
			}
		}

		// end of step printing and logging
		if (i % printerval == 0) {
			printf("%i\t%i\n", i, gMaps.survivorCount);
		}
		//writeRAW(i); // dump image
		// end of time step
	}
	// end of simulation
	int days = totalHours / 24;
	int hours = totalHours % 24;
	//printf("after %i days, %i hours: survivors=%i (%i immune) zombies=%i zombies killed=%i soldiers=%i (%i immune)\n", days, hours, gMaps.survivorCount, gMaps.immuneCount, gMaps.zombieCount, gMaps.zombiesKilled, gMaps.soldierCount, gMaps.immuneSoldierCount);
	return 0;
}

bool appendStats() {
	return true;
}

bool writeRAW(int day) {
	char name[128];
	sprintf(name, "img_hour_%06d.raw", day);
	ofstream file;
	file.open(name, ios::out | ios::binary);
	if (!file.is_open()) { return false; }
	for (int y = 0; y < MAPHEIGHT; y++) {
		for (int x = 0; x < MAPWIDTH; x++) {
			unsigned char data = 255; // default to white
			if (gMaps.zombieMap[x][y]) { data = 0; } // zombies are black
			if (gMaps.soldierMap[x][y]) { data = 128; } // soldiers are grey
			if (gMaps.survivorMap[x][y]) { data = 196; } // people are light grey
			if (gMaps.obstacleMap[x][y]) { data = 0; } // buildings are also black
			file << data;
		}
	}
	file.close();
return true;
}

