#include "maps.h"
#include <cstdlib> // rand
#include <cstdio>
using namespace std;

Maps::Maps() {
	survivorCount = 0;
	immuneCount = 0;
	soldierCount = 0;
	immuneSoldierCount = 0;
	zombieCount = 0;
	zombiesKilled = 0;

	survivorChance = 200;
	soldierChance = 5;
	buildingCoveragePercent = 10;
	buildingSizeMin = 2;
	buildingSizeMax = 10;
	
	// clear buildings
	for (int y = 0; y < MAPHEIGHT; y++) {
		for (int x = 0; x < MAPWIDTH; x++) {
			obstacleMap[x][y] = false;
		}
	}
}

void Maps::resetMoveMaps() {
	for (int y = 0; y < MAPHEIGHT; y++) {
		for (int x = 0; x < MAPWIDTH; x++) {
			zombieMovedMap[x][y] = false;
			survivorMovedMap[x][y] = false;
			soldierMovedMap[x][y] = false;
		}
	}
}

void Maps::createObstacleMap() {
	// work out how many squares to put buildings on
	int targetAmount = (buildingCoveragePercent * MAPHEIGHT * MAPWIDTH) / 100;
	int runningTotal = 0;
	while (runningTotal < targetAmount) {
		// random size
		int width = rand() % (buildingSizeMax - buildingSizeMin) + buildingSizeMin;
		int height = rand() % (buildingSizeMax - buildingSizeMin) + buildingSizeMin;
		// random start pos for building
		int startX = rand() % (MAPWIDTH - width);
		int startY = rand() % (MAPHEIGHT - height);
		for (int y = startY; y < startY + height; y++) {
			for (int x = startX; x < startX + width; x++) {
				// place brick
				if (!obstacleMap[x][y]) {
					obstacleMap[x][y] = true;
					runningTotal++;
				}
			}
		}
	}
	// clear central area to avoid blocking 1st zombie in
	for (int j = MAPHEIGHT / 2 - 5; j < MAPHEIGHT / 2 + 5; j++) {
		for (int i = MAPWIDTH / 2 - 5; i < MAPWIDTH / 2 + 5; i++) {
			obstacleMap[i][j] = false;
		}
	}
}

void Maps::createSurvivorMap() {
	// just one zombie, right in the middle of the world
	zombieMap[MAPWIDTH / 2][MAPHEIGHT / 2] = true;
	zombieCount = 1;
	
	// populate rest of world with civilians and soldiers
	for (int y = 0; y < MAPHEIGHT; y++) {
		for (int x = 0; x < MAPWIDTH; x++) {
			// skip zombie square
			if ((MAPWIDTH / 2 == x) && (MAPHEIGHT / 2 == y)) { continue; }
			// skip buildings
			if (obstacleMap[x][y]) { continue; }
			
			survivorMap[x][y] = NULL;
			zombieMap[x][y] = false;
			soldierMap[x][y] = NULL;
			int chance = rand() % 1000;
			if (chance < survivorChance) {
				survivorMap[x][y] = new Survivor;
				survivorMap[x][y]->create();
				if (survivorMap[x][y]->isImmune) {
					immuneCount++;
				}
				survivorCount++;
			} else if (chance < survivorChance + soldierChance) {
				soldierMap[x][y] = new Survivor;
				soldierMap[x][y]->create();
				if (soldierMap[x][y]->isImmune) {
					immuneSoldierCount++;
				}
				soldierCount++;
			}
		}
	}
}

void Maps::printSurvivorPositions() {
	printf("====survivor positions====\n");
	for (int x = 0; x < MAPWIDTH; x++) {
		for (int y = 0; y < MAPHEIGHT; y++) {
			if (NULL != survivorMap[x][y]) {
				printf("%i %i\n", x, y);
			}
		}
	}
}

void Maps::printZombiePositions() {
	printf("====zombie positions====\n");
	for (int x = 0; x < MAPWIDTH; x++) {
		for (int y = 0; y < MAPHEIGHT; y++) {
			if (zombieMap[x][y]) {
				printf("%i %i\n", x, y);
			}
		}
	}
}

void Maps::printSoldierPositions() {
	printf("====soldier positions====\n");
	for (int x = 0; x < MAPWIDTH; x++) {
		for (int y = 0; y < MAPHEIGHT; y++) {
			if (NULL != soldierMap[x][y]) {
				printf("%i %i\n", x, y);
			}
		}
	}
}

