#include "survivor.h"

#include <cstdlib> // rand
#include <cmath> // sqrt
#include <cstdio> // printf
using namespace std;

void Survivor::create() {
	int percentImmune = 1;
	int variation = rand() % 50 - 25; // modifier of -25 to 25
	chanceToDefend = 25 + variation; // so range is initially 0 to 50
	int chance = rand() % 100;
	if (chance < percentImmune) {
		isImmune = true;
	} else {
		isImmune = false;
	}
	experience = 0;
}

int Survivor::getDefence() {
	int def = chanceToDefend + (int)(sqrt(experience) * 10.0f);
	return def;
}

	
