/*
OpenGL Starter Code
Computer Graphics CS4052
Trinity College Dublin, Ireland

Dr Anton Gerdelan
18 Sept 2014
*/

#include <GL/glew.h> /* include this file first. this includes the newest gl.h header file on the system */
#include <GLFW/glfw3.h> /* handles creating a GL context, starting a window, and keyboard input etc. */
#include <stdio.h>

int main () {
	/* pointer to an OS window created by GLFW */
	GLFWwindow* window = NULL;
	/* pointers to strings that GL will return, giving use the version being run */
	const GLubyte* renderer;
	const GLubyte* version;
	/* Vertex Array Object (meta-data used to say WHAT data to render when drawing) */
	GLuint vao;
	/* Vertex Buffer Object (actual buffer of mesh data on the graphics hardware) */
	GLuint vbo;
	/* 3 XYZ vertex points making a triangle within space -1 to 1 on 3 axes. we will copy these into a VBO */
	GLfloat points[] = {
	  0.0f,  0.5f,  0.0f,
	  0.5f, -0.5f,  0.0f,
	 -0.5f, -0.5f,  0.0f
	};

	/* start GL context and O/S window using the GLFW helper library */
	if (!glfwInit ()) {
		fprintf (stderr, "ERROR: could not start GLFW3\n");
		return 1;
	} 

	/* change to 3.2 if on Apple OS X
	glfwWindowHint (GLFW_CONTEXT_VERSION_MAJOR, 4);
	glfwWindowHint (GLFW_CONTEXT_VERSION_MINOR, 0);
	glfwWindowHint (GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
	glfwWindowHint (GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE); */

	/* ask GLFW library to create an OS window */
	window = glfwCreateWindow (640, 480, "Hello Triangle", NULL, NULL);
	if (!window) {
		fprintf (stderr, "ERROR: opening OS window\n");
		return 1;
	}
	/* hook up an OpenGL context (running copy of GL) with the window */
	glfwMakeContextCurrent (window);

	/* start the GLEW library - makes sure that the latest GL library headers are used, and handles any
	extensions (new plug-in features that aren't part of GL yet) that we want to use */
	glewExperimental = GL_TRUE;
	glewInit ();

	/* get version info */
	renderer = glGetString (GL_RENDERER); /* get renderer string */
	version = glGetString (GL_VERSION); /* version as a string */
	printf ("Renderer: %s\n", renderer);
	printf ("OpenGL version supported %s\n", version);

	/* tell GL to only draw onto a pixel if the shape is closer to the viewer
	we aren't using this yet but you'll need it later */
	glEnable (GL_DEPTH_TEST); /* enable depth-testing */
	glDepthFunc (GL_LESS); /*depth-testing interprets a smaller value as "closer"*/

	/* ask GL to generate a VBO, and give us a handle to refer to it with */
	glGenBuffers (1, &vbo);
	/* "bind" the VBO. all future VBO operations affect this VBO until we bind a different one */
	glBindBuffer (GL_ARRAY_BUFFER, vbo);
	/* copy our points from RAM into our VBO on graphics hardware */
	glBufferData (GL_ARRAY_BUFFER, sizeof (points), points, GL_STATIC_DRAW);
	
	/* ask GL to generate a VAO, and give us a handle to refer to it with */
	glGenVertexArrays (1, &vao);
	/* "bind" the VAO */
	glBindVertexArray (vao);
	/* tell the VAO that it should enable the first shader input variable (number 0) */
	glEnableVertexAttribArray (0);
	/* bind our VBO. it's already bound at the moment but this is good practice in case of code
	changes later */
	glBindBuffer (GL_ARRAY_BUFFER, vbo);
	/* tell the VAO that it should use our VBO to find its first input variable (number 0).
	that input variable should use 3 consecutive floats as a variable (it will be a vec3)
	GL_FALSE means we dont need to normalise it (useful for some clever data tricks in advanced stuff)
	each variable comes one-after-the-other in the data, so there's no need for stride (0), and starts at
	the beginning of the buffer, so no offset either (NULL) */
	glVertexAttribPointer (0, 3, GL_FLOAT, GL_FALSE, 0, NULL);

	/* vertex shader simply uses our input variables from the VBO and uses them as the final on-sreen position
	of a vertex (one vertex = one shader executed) */
	const char* vertex_shader =
		"#version 400\n" // use GLSL version 4.0.0
		"in vec3 vp;" // our vertex position input variable, which we set up the data for
		"void main () {" // entry point of shader code
		"  gl_Position = vec4 (vp, 1.0);" // the built-in vec4 gl_Position variable must be set in a vertex shader
		"}";
	/* fragment shader simply sets each fragment (pixel-side piece of each 2d triangle) to a colour in RGBA
	(red blue green alpha) values from 0.0 to 1.0. one fragment = one fragment shader executed */
	const char* fragment_shader =
		"#version 400\n"
		"out vec4 frag_colour;" // the first output variable is used as the fragment colour
		"void main () {"
		"  frag_colour = vec4 (0.5, 0.0, 0.5, 1.0);" // this is another type of constructor for a vec4
		"}";
	/* GL shader objets for vertex shader and fragment shader. we copy the source strings into these and
	compile them separately */
	GLuint vs, fs;
	/* after that we attach both compiled shader objects to a shader program object, which we link. then we
	can use it for any drawing operations */
	GLuint shader_programme;
	/* ask GL to create a shader object for us */
	vs = glCreateShader (GL_VERTEX_SHADER);
	/* copy string into object */
	glShaderSource (vs, 1, &vertex_shader, NULL);
	/* compile shader */
	glCompileShader (vs);
	fs = glCreateShader (GL_FRAGMENT_SHADER);
	glShaderSource (fs, 1, &fragment_shader, NULL);
	glCompileShader (fs);
	shader_programme = glCreateProgram ();
	/* attach both compiled shaders to sp */
	glAttachShader (shader_programme, fs);
	glAttachShader (shader_programme, vs);
	/* link the shader program. this does things like match vertex shader outputs to fragment shader
	inputs */
	glLinkProgram (shader_programme);
	/* NOTE: you should check for errors and print logs after compiling and also linking shaders */

	/* start drawing loop until we click on the close window button */
	while (!glfwWindowShouldClose (window)) {
		/* wipe drawing framebuffer clear. clears colour buffer and also depth buffer
		we're not using the depth buffer bit but it's not harm to do this too now */
		glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); 
		
		/* bind ("use") our shader program as the drawing style for all future subsequent, until another
		shader program is used */
		glUseProgram (shader_programme);
		/* bind our VAO as the data and variables to use for all subsequent drawing, until we call this
		with a different VAO */
		glBindVertexArray (vao);
		
		/* draw, using the bound VAO, and used shader programme
		we draw triangles from every 3 XYZ points, and draw 3 XYZ points, starting at index 0 */
		glDrawArrays (GL_TRIANGLES, 0, 3);

		/* this just updates window events and keyboard input events (not used yet) */
		glfwPollEvents ();
		/* swaps the buffer that we are drawing to, and the one currently displayed on the window */
		glfwSwapBuffers (window);
	}

	return 0;
}